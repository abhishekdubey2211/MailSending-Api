package com.file;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
